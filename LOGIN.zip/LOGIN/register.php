<?php

include 'config.php';

if(isset($_POST['submit'])){

   $fname = mysqli_real_escape_string($conn, $_POST['fname']);
   $mname = mysqli_real_escape_string($conn, $_POST['mname']);
   $lname = mysqli_real_escape_string($conn, $_POST['lname']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $phone = mysqli_real_escape_string($conn, $_POST['phone']);
   $pass = mysqli_real_escape_string($conn, md5($_POST['password']));
   $cpass = mysqli_real_escape_string($conn, md5($_POST['cpassword']));
   $image = $_FILES['image']['name'];
   $image_size = $_FILES['image']['size'];
   $image_tmp_name = $_FILES['image']['tmp_name'];
   $image_folder = 'uploaded_img/'.$image;

   $select = mysqli_query($conn, "SELECT * FROM `user_form` WHERE email = '$email' AND password = '$pass'") or die('query failed');

   if(mysqli_num_rows($select) > 0){
      $message[] = 'User already exists'; 
   }else{
      if($pass != $cpass){
         $message[] = 'Confirm password not matched!';
      }elseif($image_size > 2000000){
         $message[] = 'Image size is too large!';
      }else{
         $insert = mysqli_query($conn, "INSERT INTO `user_form`(fname, mname, lname, email, phone, password, image) VALUES('$fname', '$mname', '$lname', '$email', '$phone', '$pass', '$image')") or die('query failed');

         if($insert){
            move_uploaded_file($image_tmp_name, $image_folder);
            $message[] = 'Registered successfully!';
            header('location:login.php');
         }else{
            $message[] = 'Registration failed!';
         }
      }
   }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register</title>
   <!-- AdminLTE CSS -->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css">
   <!-- Font Awesome -->
   <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
</head>
<body class="hold-transition register-page">
<div class="register-box">
   <div class="register-logo">
      <a href="#"><b>Admin</b>LTE</a>
   </div>
   <div class="card">
      <div class="card-body register-card-body">
         <p class="login-box-msg">Register a new membership</p>

         <form action="" method="post" enctype="multipart/form-data">
            <?php
            if (isset($message)) {
               foreach ($message as $msg) {
                  echo '<div class="alert alert-danger">' . $msg . '</div>';
               }
            }
            ?>
            <div class="input-group mb-3">
               <input type="text" name="fname" class="form-control" placeholder="First Name" required>
               <div class="input-group-append">
                  <div class="input-group-text">
                     <span class="fas fa-user"></span>
                  </div>
               </div>
            </div>
            <div class="input-group mb-3">
               <input type="text" name="mname" class="form-control" placeholder="Middle Name">
               <div class="input-group-append">
                  <div class="input-group-text">
                     <span class="fas fa-user"></span>
                  </div>
               </div>
            </div>
            <div class="input-group mb-3">
               <input type="text" name="lname" class="form-control" placeholder="Last Name" required>
               <div class="input-group-append">
                  <div class="input-group-text">
                     <span class="fas fa-user"></span>
                  </div>
               </div>
            </div>
            <div class="input-group mb-3">
               <input type="email" name="email" class="form-control" placeholder="Email" required>
               <div class="input-group-append">
                  <div class="input-group-text">
                     <span class="fas fa-envelope"></span>
                  </div>
               </div>
            </div>
            <div class="input-group mb-3">
               <input type="text" name="phone" class="form-control" placeholder="Phone Number">
               <div class="input-group-append">
                  <div class="input-group-text">
                     <span class="fas fa-phone"></span>
                  </div>
               </div>
            </div>
            <div class="input-group mb-3">
               <input type="password" name="password" class="form-control" placeholder="Password" required>
               <div class="input-group-append">
                  <div class="input-group-text">
                     <span class="fas fa-lock"></span>
                  </div>
               </div>
            </div>
            <div class="input-group mb-3">
               <input type="password" name="cpassword" class="form-control" placeholder="Confirm Password" required>
               <div class="input-group-append">
                  <div class="input-group-text">
                     <span class="fas fa-lock"></span>
                  </div>
               </div>
            </div>
            <div class="input-group mb-3">
               <input type="file" name="image" class="form-control" accept="image/jpg, image/jpeg, image/png">
               <div class="input-group-append">
                  <div class="input-group-text">
                     <span class="fas fa-image"></span>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-8">
                  <div class="icheck-primary">
                     <input type="checkbox" id="agreeTerms" name="agreeTerms" value="agree" required>
                     <label for="agreeTerms">
                        I agree to the <a href="#">terms</a>
                     </label>
                  </div>
               </div>
               <div class="col-4">
                  <button type="submit" name="submit" class="btn btn-primary btn-block">Register</button>
               </div>
            </div>
         </form>

         <div class="social-auth-links text-center">
            <p>- OR -</p>
            <a href="#" class="btn btn-block btn-primary">
               <i class="fab fa-facebook mr-2"></i>
               Sign up using Facebook
            </a>
            <a href="#" class="btn btn-block btn-danger">
               <i class="fab fa-google-plus mr-2"></i>
               Sign up using Google+
            </a>
         </div>

         <a href="login.php" class="text-center">I already have a membership</a>
      </div>
   </

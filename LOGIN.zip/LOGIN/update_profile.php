<?php

include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];

if(isset($_POST['update_profile'])){

   $update_fname = mysqli_real_escape_string($conn, $_POST['update_fname']);
   $update_mname = mysqli_real_escape_string($conn, $_POST['update_mname']);
   $update_lname = mysqli_real_escape_string($conn, $_POST['update_lname']);
   $update_phone = mysqli_real_escape_string($conn, $_POST['update_phone']);
   $update_email = mysqli_real_escape_string($conn, $_POST['update_email']);

   // Check if a file is selected for upload
   if(isset($_FILES['update_image']) && $_FILES['update_image']['error'] === UPLOAD_ERR_OK) {
      $update_image = $_FILES['update_image']['name'];
      $update_image_tmp_name = $_FILES['update_image']['tmp_name'];
      $update_image_folder = 'uploaded_img/'.$update_image;

      // Move uploaded file to the desired location
      move_uploaded_file($update_image_tmp_name, $update_image_folder);

      // Update the database with the new image path
      mysqli_query($conn, "UPDATE `user_form` SET fname = '$update_fname', mname = '$update_mname', lname = '$update_lname', phone = '$update_phone', email = '$update_email', image = '$update_image' WHERE id = '$user_id'") or die('query failed');
   } else {
      // If no new image is uploaded, update other fields except the image
      mysqli_query($conn, "UPDATE `user_form` SET fname = '$update_fname', mname = '$update_mname', lname = '$update_lname', phone = '$update_phone', email = '$update_email' WHERE id = '$user_id'") or die('query failed');
   }

   // Rest of your code for updating password...
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Update Profile</title>

   <!-- Bootstrap CSS -->
   <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
   <!-- Font Awesome -->
   <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
   <!-- Custom CSS -->
   <style>
      .box-container {
         max-width: 500px;
         margin: auto;
         margin-top: 50px;
         border: 1px solid #ccc;
         border-radius: 5px;
         padding: 20px;
         background-color: #e9f0fb; /* Blue background */
         color: #333; /* Black text */
      }
      .box-container h2 {
         color: #dc3545; /* Red heading */
      }
      .profile-img {
         max-width: 150px;
         margin: auto;
         margin-bottom: 20px;
      }
   </style>
</head>
<body>

<div class="container">
   <div class="box-container">
      <?php
         $select = mysqli_query($conn, "SELECT * FROM `user_form` WHERE id = '$user_id'") or die('query failed');
         if(mysqli_num_rows($select) > 0){
            $fetch = mysqli_fetch_assoc($select);
         }
      ?>

      <form action="" method="post" enctype="multipart/form-data">
         <div class="text-center profile-img">
            <?php
               if($fetch['image'] == ''){
                  echo '<img src="images/default-avatar.png" class="img-fluid rounded-circle" alt="Profile Picture">';
               }else{
                  echo '<img src="uploaded_img/'.$fetch['image'].'" class="img-fluid rounded-circle" alt="Profile Picture">';
               }
            ?>
         </div>

         <div class="form-group">
            <label for="update_fname">First Name:</label>
            <input type="text" name="update_fname" value="<?php echo $fetch['fname']; ?>" class="form-control">
         </div>

         <div class="form-group">
            <label for="update_mname">Middle Name:</label>
            <input type="text" name="update_mname" value="<?php echo $fetch['mname']; ?>" class="form-control">
         </div>

         <div class="form-group">
            <label for="update_lname">Last Name:</label>
            <input type="text" name="update_lname" value="<?php echo $fetch['lname']; ?>" class="form-control">
         </div>

         <div class="form-group">
            <label for="update_phone">Phone Number:</label>
            <input type="text" name="update_phone" value="<?php echo $fetch['phone']; ?>" class="form-control">
         </div>

         <div class="form-group">
            <label for="update_email">Your Email:</label>
            <input type="email" name="update_email" value="<?php echo $fetch['email']; ?>" class="form-control">
         </div>

         <div class="form-group">
            <label for="update_image">Update Profile Picture:</label>
            <input type="file" name="update_image" class="form-control-file">
         </div>

         <!-- Rest of your form fields (password and image) -->

         <button type="submit" name="update_profile" class="btn btn-primary">Update Profile</button>
         <a href="home.php" class="btn btn-secondary">Go Back</a>
      </form>
   </div>
</div>

</body>
</html>

<?php

$conn = mysqli_connect('localhost','root','','LOGIN') or die('connection failed');

?>
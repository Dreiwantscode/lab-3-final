<?php
include 'config.php';
session_start();

if (isset($_POST['submit'])) {
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = mysqli_real_escape_string($conn, md5($_POST['password']));

   $select = mysqli_query($conn, "SELECT * FROM `user_form` WHERE email = '$email' AND password = '$pass'") or die('query failed');

   if (mysqli_num_rows($select) > 0) {
      $row = mysqli_fetch_assoc($select);
      $_SESSION['user_id'] = $row['id'];
      header('location:home.php');
   } else {
      $message[] = 'Incorrect email or password!';
   }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login</title>
   <!-- AdminLTE CSS -->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/css/adminlte.min.css">
   <!-- Font Awesome -->
   <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
   <style>
      .login-page {
         background-color: #f4f6f9;
      }
      .login-logo a {
         color: #343a40;
      }
      .card {
         border-radius: 0.75rem;
      }
      .card-body {
         padding: 2rem;
      }
   </style>
</head>
<body class="hold-transition login-page">

<div class="login-box">
   <div class="login-logo">
      <a href="#"><b>Admin</b>LTE</a>
   </div>
   <!-- /.login-logo -->
   <div class="card">
      <div class="card-body login-card-body">
         <p class="login-box-msg">Sign in to start your session</p>

         <form action="" method="post" enctype="multipart/form-data">
            <?php
            if (isset($message)) {
               foreach ($message as $msg) {
                  echo '<div class="alert alert-danger">' . $msg . '</div>';
               }
            }
            ?>
            <div class="input-group mb-3">
               <input type="email" name="email" class="form-control" placeholder="Email" required>
               <div class="input-group-append">
                  <div class="input-group-text">
                     <span class="fas fa-envelope"></span>
                  </div>
               </div>
            </div>
            <div class="input-group mb-3">
               <input type="password" name="password" class="form-control" placeholder="Password" required>
               <div class="input-group-append">
                  <div class="input-group-text">
                     <span class="fas fa-lock"></span>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-8">
                  <div class="icheck-primary">
                     <input type="checkbox" id="remember">
                     <label for="remember">
                        Remember Me
                     </label>
                  </div>
               </div>
               <!-- /.col -->
               <div class="col-4">
                  <button type="submit" name="submit" class="btn btn-primary btn-block">Sign In</button>
               </div>
               <!-- /.col -->
            </div>
         </form>

         <div class="social-auth-links text-center mt-2 mb-3">
            <p>- OR -</p>
            <a href="#" class="btn btn-block btn-primary">
               <i class="fab fa-facebook mr-2"></i> Sign in using Facebook
            </a>
            <a href="#" class="btn btn-block btn-danger">
               <i class="fab fa-google-plus mr-2"></i> Sign in using Google+
            </a>
         </div>

         <p class="mb-1">
            <a href="forgot.php">I forgot my password</a>
         </p>
         <p class="mb-0">
            <a href="register.php" class="text-center">Register a new membership</a>
         </p>
      </div>
      <!-- /.login-card-body -->
   </div>
</div>
<!-- /.login-box -->

<!-- AdminLTE JS -->
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<!-- Bootstrap 4 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <!-- Linking Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Rock+Salt&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background-image: url('pick.gif');
            background-size: cover;
            background-position: center;
            height: 100vh;
            margin: 0;
            padding: 0;
            color: white; /* Set text color to white */
            font-family: 'Kaushan Script', cursive; /* Apply anime-like font to body */
        }
        h1,
        label,
        .checkbox label,
        .btn-primary,
        a {
            font-family: 'Kaushan Script', cursive; /* Apply anime-like font to specified elements */
            color: white; /* Ensure text color is white */
        }
        input {
            font-family: inherit; /* Use the inherited font for input fields */
        }
    </style>
</head>
<body>
    <!-- Container for registration form -->
    <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh">
        <!-- Registration Form -->
        <form action="register.php" method="post" class="border shadow p-3 rounded" style="width: 500px;">
            <h1 class="text-center p-3">REGISTER</h1>
            <?php if (isset($_GET['error'])) { ?>
                <div class="alert alert-danger">
                    <?php echo $_GET['error']; ?>
                </div>
            <?php } ?>

            <!-- First Name Input Field -->
            <div class="mb-3">
                <label for="First_name" class="form-label">Firstname</label>
                <input type="text" class="form-control" name="fname" placeholder="Firstname" value="<?php echo $_GET['fname'] ?? ''; ?>" pattern="[A-Za-z ]+" title="numbers are not allowed!">
            </div>

            <!-- Middle Name Input Field -->
            <div class="mb-3">
                <label for="middle_name" class="form-label">Middle name</label>
                <input type="text" class="form-control" name="mname" placeholder="Middle name / optional" value="<?php echo $_GET['mname'] ?? ''; ?>" pattern="[A-Za-z.]+"
                title="numbers are not allowed!">
            </div>

            <!-- Last Name Input Field -->
            <div class="mb-3">
                <label for="Last_name" class="form-label">Lastname</label>
                <input type="text" class="form-control" name="lname" placeholder="Lastname" value="<?php echo $_GET['lname'] ?? ''; ?>" pattern="[A-Za-z]+" title="numbers are not allowed!">
            </div>

            <!-- Username Input Field -->
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" name="uname" placeholder="Username" value="<?php echo $_GET['uname'] ?? ''; ?>">
            </div>

            <!-- Email Input Field -->
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo $_GET['email'] ?? ''; ?>" pattern="^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$" title='please include " . " in your email!'>
            </div>

            <!-- Password Input Field -->
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" name="password" placeholder="Password">
            </div>

            <!-- Re-enter Password Input Field -->
            <div class="mb-3">
                <label for="Retype_password" class="form-label">Retype password</label>
                <input type="password" class="form-control" name="repassword" placeholder="Retype password">
            </div>

            <hr>
            <!-- Submit Button -->
            <button class="btn btn-primary float-end" type="submit">Create account</button>

            <!-- Terms and Conditions Checkbox -->
            <div class="checkbox">
                <label>
                    <input type="checkbox" name="terms"> I agree to the terms and conditions
                </label>
            </div>

            <!-- Link to Login Form -->
            <div>
                Already have an account? <a href="Loginform.php">Login</a>
            </div>
        </form> 
    </div>
</body>
</html>


<?php
session_start();

// Check if the user is not logged in, then redirect to login page
if (!isset($_SESSION['username'])) {
    header('Location: loginform.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap.css">

    <style>
        /* CSS to set background image */
        body {
            /* Add your JPG image path and set properties */
            background-image: url('dark.jpg');
            /* Adjust background properties as needed */
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        /* Style changes */
        .card {
            background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */
            border-radius: 15px; /* Rounded corners */
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.5); /* Shadow effect */
        }

        .card-header {
            background-color: transparent; /* Transparent header */
            border-bottom: none; /* No bottom border */
        }

        .card-footer {
            background-color: transparent; /* Transparent footer */
            border-top: none; /* No top border */
        }

        .btn-outline-danger {
            color: #dc3545; /* Red color for logout button */
            border-color: #dc3545; /* Red border color */
        }

        .btn-outline-danger:hover {
            color: #fff; /* White text on hover */
            background-color: #dc3545; /* Red background on hover */
            border-color: #dc3545; /* Red border color on hover */
        }
    </style>
</head>
<body class="bg-danger">
    <div class="container mt-5 ">
        <!-- Row to justify content in the center -->
        <div class="row justify-content-center ">
            <!-- Column with medium width -->
            <div class="col-md-6 ">
                <!-- Card with a border and info outline -->
                <div class="card border-outline-danger" >
                    <div class="card-header">
                        <!-- Heading with large text and centered alignment -->    
                        <h1 class="display-4 text-center text-danger">Logged in!</h1>
                    </div>
                    <div class="card-body">
                        <h2 class="display-2 text-center text-danger">andrei</h2>
                    </div>
                    <div class="card-footer">
                        <a href="logout.php" class="btn btn-outline-danger d-grid gap-2 col-6 mx-auto" >Logout </a>
                    </div>
                </div>
            </div>
        </div>
    </div> 
</body>
</html>
